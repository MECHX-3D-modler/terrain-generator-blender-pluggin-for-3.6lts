"""Shared helpers: collections, object-mode guard, cleanup, stats."""
import bpy

ROOT_COLL = "LPS_Set"
SCATTER_COLL = "LPS_Scatter"
TERRAIN_NAME = "LPS_Terrain"
WATER_NAME = "LPS_Water"
SUN_NAME = "LPS_Sun"
CAM_NAME = "LPS_Camera"
PIVOT_NAME = "LPS_CamPivot"
MERGED_NAME = "LPS_Scatter_Merged"

TRI_BUDGET = 60000
OBJ_BUDGET = 1000


def ensure_object_mode(context):
    if context.mode != "OBJECT" and context.view_layer.objects.active:
        bpy.ops.object.mode_set(mode="OBJECT")


def get_collection(scene, name, parent=None):
    coll = bpy.data.collections.get(name)
    if coll is None:
        coll = bpy.data.collections.new(name)
    parent = parent or scene.collection
    if coll.name not in parent.children:
        parent.children.link(coll)
    return coll


def root_collection(scene):
    return get_collection(scene, ROOT_COLL)


def scatter_collection(scene):
    return get_collection(scene, SCATTER_COLL, root_collection(scene))


def get_mesh(name):
    """Reuse a mesh datablock by name (cleared) instead of making new ones."""
    mesh = bpy.data.meshes.get(name)
    if mesh is None:
        mesh = bpy.data.meshes.new(name)
    else:
        mesh.clear_geometry()
    return mesh


def get_object(name, data, coll):
    obj = bpy.data.objects.get(name)
    if obj is None:
        obj = bpy.data.objects.new(name, data)
    elif obj.data is not data:
        obj.data = data
    if obj.name not in coll.objects:
        coll.objects.link(obj)
    return obj


def purge_own_orphans():
    """Remove only this add-on's unused meshes (never touches user data)."""
    dead = [m for m in bpy.data.meshes if m.name.startswith("LPS_") and m.users == 0]
    if dead:
        bpy.data.batch_remove(dead)


def update_stats(scene):
    """Count once after an operation; the panel only reads the stored numbers."""
    tris = 0
    objs = 0
    root = bpy.data.collections.get(ROOT_COLL)
    if root:
        for obj in root.all_objects:
            objs += 1
            if obj.type == "MESH":
                tris += len(obj.data.polygons)  # all LPS meshes are triangles
    scene.lps.stat_tris = tris
    scene.lps.stat_objects = objs


def vertex_color_viewport(context):
    """Show vertex colors in Solid mode: the cheapest way to preview."""
    screen = context.screen
    if not screen:
        return
    for area in screen.areas:
        if area.type == "VIEW_3D":
            shading = area.spaces.active.shading
            if shading.type == "SOLID":
                shading.color_type = "VERTEX"


def try_set(obj, attr, value):
    try:
        setattr(obj, attr, value)
    except (AttributeError, TypeError, ValueError):
        pass
