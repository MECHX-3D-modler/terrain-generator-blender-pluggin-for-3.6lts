"""Low-poly terrain: jittered triangle grid, fractal noise, falloff, terraces."""
import math
import random

from mathutils import Vector, noise

from . import palette, utils

NOISE_ITEMS = [
    ("PERLIN", "Perlin", "Rolling hills"),
    ("RIDGED", "Ridged", "Sharp mountain ridges"),
    ("VORONOI", "Voronoi", "Cellular bumps and mesas"),
    ("BLENDER", "Soft", "Soft blobby hills"),
]
FALLOFF_ITEMS = [
    ("NONE", "None", "Open terrain"),
    ("ISLAND", "Island", "Land in the middle, sea at the edges"),
    ("RADIAL", "Mountain", "One big peak in the middle"),
    ("VALLEY", "Valley", "Low strip through the middle"),
    ("CANYON", "Canyon", "Winding river channel"),
]


def _smooth(e0, e1, x):
    t = min(1.0, max(0.0, (x - e0) / (e1 - e0)))
    return t * t * (3 - 2 * t)


def _raw_noise(p, kind, octaves):
    if kind == "RIDGED":
        return noise.ridged_multi_fractal(p, 1.0, 2.0, octaves, 1.0, 2.0,
                                          noise_basis="PERLIN_ORIGINAL")
    basis = {"PERLIN": "PERLIN_ORIGINAL", "VORONOI": "VORONOI_F1",
             "BLENDER": "BLENDER"}[kind]
    return noise.fractal(p, 1.0, 2.0, octaves, noise_basis=basis)


def _falloff(h, u, v, mode):
    r = math.sqrt(u * u + v * v)
    if mode == "ISLAND":
        return (0.25 + 0.75 * h) * (1.0 - _smooth(0.35, 0.95, r))
    if mode == "RADIAL":
        m = max(0.0, 1.0 - r) ** 1.5
        return 0.25 * h + 0.75 * m * (0.6 + 0.4 * h)
    if mode == "VALLEY":
        m = _smooth(0.05, 0.75, abs(u))
        return 0.12 * h + 0.88 * m * (0.4 + 0.6 * h)
    if mode == "CANYON":
        d = abs(u - 0.25 * math.sin(v * 3.0))
        return (0.55 + 0.45 * h) * _smooth(0.12, 0.4, d)
    return h


def height_field(s, xs, ys):
    """Return normalized 0..1 heights for the given XY lists."""
    rng = random.Random(s.seed)
    off = Vector((rng.uniform(-500, 500), rng.uniform(-500, 500), rng.uniform(-500, 500)))
    k = s.noise_scale * 3.0 / max(s.size, 1e-6)
    raw = [_raw_noise(Vector((x * k, y * k, 0.0)) + off, s.noise_type, s.octaves)
           for x, y in zip(xs, ys)]
    lo, hi = min(raw), max(raw)
    span = (hi - lo) or 1.0
    half = s.size * 0.5
    out = []
    steps = s.terrace_steps
    for h, x, y in zip(raw, xs, ys):
        h = (h - lo) / span
        u, v = x / half, y / half
        h = _falloff(h, u, v, s.falloff)
        if s.edge_drop > 0:
            h *= 1.0 - _smooth(1.0 - s.edge_drop, 1.0, max(abs(u), abs(v)))
        if steps > 0:
            h = round(h * steps) / steps
        out.append(h)
    return out


def build_terrain(context):
    scene = context.scene
    s = scene.lps
    n = s.subdivisions
    size = s.size
    cell = size / n
    half = size * 0.5
    rng = random.Random(s.seed + 1)
    jit = s.jitter * cell * 0.45

    xs, ys = [], []
    for j in range(n + 1):
        for i in range(n + 1):
            x = -half + i * cell
            y = -half + j * cell
            if 0 < i < n and 0 < j < n and jit > 0:
                x += rng.uniform(-jit, jit)
                y += rng.uniform(-jit, jit)
            xs.append(x)
            ys.append(y)
    hs = height_field(s, xs, ys)
    verts = [(x, y, h * s.height) for x, y, h in zip(xs, ys, hs)]

    faces = []
    row = n + 1
    for j in range(n):
        for i in range(n):
            a = j * row + i
            b, c, d = a + 1, a + row + 1, a + row
            if (i + j) % 2:  # alternate diagonals for the faceted look
                faces += [(a, b, c), (a, c, d)]
            else:
                faces += [(a, b, d), (b, c, d)]

    mesh = utils.get_mesh(utils.TERRAIN_NAME)
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    mesh.materials.clear()
    mesh.materials.append(palette.get_material())
    obj = utils.get_object(utils.TERRAIN_NAME, mesh, utils.root_collection(scene))
    palette.paint_terrain(obj, s)
    return obj


def get_terrain():
    import bpy
    return bpy.data.objects.get(utils.TERRAIN_NAME)
