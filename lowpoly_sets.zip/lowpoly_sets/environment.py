"""Water plane, flat sky, one sun, optional cheap fog, and a camera rig."""
import math

import bpy
from mathutils import Vector

from . import palette, utils

TIME_ITEMS = [
    ("MORNING", "Morning", ""),
    ("NOON", "Noon", ""),
    ("SUNSET", "Sunset", ""),
    ("NIGHT", "Night", ""),
]
TIME_PRESETS = {
    "MORNING": dict(sun_elevation=20, sun_azimuth=60, sun_strength=3.0,
                    sun_color=(1.0, 0.85, 0.7), sky_color=(0.50, 0.69, 0.87)),
    "NOON":    dict(sun_elevation=60, sun_azimuth=140, sun_strength=4.0,
                    sun_color=(1.0, 0.97, 0.92), sky_color=(0.35, 0.63, 1.0)),
    "SUNSET":  dict(sun_elevation=8, sun_azimuth=250, sun_strength=3.0,
                    sun_color=(1.0, 0.55, 0.3), sky_color=(0.87, 0.35, 0.16)),
    "NIGHT":   dict(sun_elevation=35, sun_azimuth=200, sun_strength=0.6,
                    sun_color=(0.6, 0.7, 1.0), sky_color=(0.01, 0.017, 0.05)),
}


def build_water(scene):
    s = scene.lps
    obj = bpy.data.objects.get(utils.WATER_NAME)
    if not s.use_water:
        if obj:
            bpy.data.objects.remove(obj)
            utils.purge_own_orphans()
        return None
    h = s.size * 0.5 * 6  # still 2 tris; big enough to hide the edge
    z = s.water_level * s.height
    mesh = utils.get_mesh(utils.WATER_NAME)
    mesh.from_pydata([(-h, -h, 0), (h, -h, 0), (h, h, 0), (-h, h, 0)], [],
                     [(0, 1, 2), (0, 2, 3)])
    mesh.materials.clear()
    mesh.materials.append(palette.get_water_material(s.palette))
    obj = utils.get_object(utils.WATER_NAME, mesh, utils.root_collection(scene))
    obj.location = (0, 0, z)
    obj.color = (*palette.color(s.palette, "water"), 1.0)
    return obj


def build_world(scene):
    s = scene.lps
    world = bpy.data.worlds.get("LPS_World") or bpy.data.worlds.new("LPS_World")
    world.use_nodes = True
    nt = world.node_tree
    bg = nt.nodes.get("Background") or nt.nodes.new("ShaderNodeBackground")
    bg.inputs["Color"].default_value = (*s.sky_color, 1.0)
    bg.inputs["Strength"].default_value = 1.0 if s.time_of_day != "NIGHT" else 0.4
    world.color = s.sky_color
    out = next((n for n in nt.nodes if n.type == "OUTPUT_WORLD"), None) \
        or nt.nodes.new("ShaderNodeOutputWorld")
    if not bg.outputs[0].is_linked:
        nt.links.new(bg.outputs[0], out.inputs["Surface"])
    fog = nt.nodes.get("LPS_Fog")
    if s.use_fog:
        if fog is None:
            fog = nt.nodes.new("ShaderNodeVolumePrincipled")
            fog.name = "LPS_Fog"
        fog.inputs["Density"].default_value = s.fog_density
        fog.inputs["Color"].default_value = (*s.sky_color, 1.0)
        nt.links.new(fog.outputs[0], out.inputs["Volume"])
        utils.try_set(scene.eevee, "volumetric_tile_size", "16")
        utils.try_set(scene.eevee, "volumetric_samples", 32)
        utils.try_set(scene.eevee, "volumetric_end", s.size * 3)
    elif fog:
        nt.nodes.remove(fog)
    scene.world = world


def build_sun(scene):
    s = scene.lps
    light = bpy.data.lights.get(utils.SUN_NAME) or bpy.data.lights.new(utils.SUN_NAME, "SUN")
    light.energy = s.sun_strength
    light.color = s.sun_color
    light.angle = math.radians(3)
    utils.try_set(light, "use_contact_shadow", False)
    utils.try_set(light, "shadow_cascade_count", 2)
    utils.try_set(light, "shadow_cascade_max_distance", s.size * 2.5)
    obj = utils.get_object(utils.SUN_NAME, light, utils.root_collection(scene))
    obj.location = (0, 0, s.height + 10)
    obj.rotation_euler = (math.radians(90 - s.sun_elevation), 0, math.radians(s.sun_azimuth))
    # Cheap, clean shadows
    utils.try_set(scene.eevee, "shadow_cascade_size", "1024")
    utils.try_set(scene.eevee, "use_soft_shadows", False)
    return obj


def build_environment(scene):
    build_water(scene)
    build_world(scene)
    build_sun(scene)


def _look_at(obj, target):
    d = Vector(target) - obj.location
    obj.rotation_euler = d.to_track_quat("-Z", "Y").to_euler()


def build_camera(scene):
    s = scene.lps
    root = utils.root_collection(scene)
    cam_data = bpy.data.cameras.get(utils.CAM_NAME) or bpy.data.cameras.new(utils.CAM_NAME)
    cam_data.lens = 35
    cam_data.clip_end = s.size * 8
    cam = utils.get_object(utils.CAM_NAME, cam_data, root)
    cam.parent = None
    cam.animation_data_clear()
    pivot = bpy.data.objects.get(utils.PIVOT_NAME)
    target = (0, 0, s.height * 0.3)

    if s.camera_mode == "ORBIT":
        if pivot is None:
            pivot = bpy.data.objects.new(utils.PIVOT_NAME, None)
        if pivot.name not in root.objects:
            root.objects.link(pivot)
        pivot.location = target
        pivot.rotation_euler = (0, 0, 0)
        pivot.animation_data_clear()
        cam.location = (0, -s.size * 0.95, s.height + s.size * 0.3)
        _look_at(cam, target)
        cam.location -= Vector(target)
        cam.parent = pivot
        f0, f1 = scene.frame_start, scene.frame_end
        pivot.keyframe_insert("rotation_euler", index=2, frame=f0)
        pivot.rotation_euler.z = math.tau
        pivot.keyframe_insert("rotation_euler", index=2, frame=f1 + 1)
        for fc in pivot.animation_data.action.fcurves:
            for kp in fc.keyframe_points:
                kp.interpolation = "LINEAR"
        pivot.rotation_euler.z = 0
    else:
        if pivot:
            bpy.data.objects.remove(pivot)
        cam.location = (s.size * 0.75, -s.size * 0.75, s.height + s.size * 0.35)
        _look_at(cam, target)
    scene.camera = cam
    return cam
