"""Color palettes, the single shared material, and vertex-color painting."""
import bpy
import numpy as np

COLOR_ATTR = "Col"
MATERIAL_NAME = "LPS_Material"
WATER_MAT_NAME = "LPS_WaterMat"


def _hex(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4))


# Colors are written in sRGB hex and converted to linear on use.
PALETTES = {
    "TROPICAL": dict(seabed="#c9b27c", sand="#f2dca0", grass="#7cc552", grass2="#3f8f3a",
                     rock="#8a8070", snow="#ffffff", water="#3fb8d8", trunk="#7a5230",
                     leaf="#4caf50", leaf2="#2e7d32", stone="#9a9488", cactus="#5a9a4a"),
    "FOREST": dict(seabed="#6d6a4e", sand="#b9a77a", grass="#6aa841", grass2="#2f6b2a",
                   rock="#6f6a60", snow="#f4f7fa", water="#3b8fb0", trunk="#5e3f24",
                   leaf="#3f8f3f", leaf2="#1f5a2e", stone="#7d786e", cactus="#4f8a42"),
    "DESERT": dict(seabed="#b58a52", sand="#e8c07a", grass="#d9ad68", grass2="#c08a4e",
                   rock="#a0583a", snow="#efdcb8", water="#4fa3b8", trunk="#7a5636",
                   leaf="#8a9a4a", leaf2="#6b7a3a", stone="#b07a55", cactus="#5f8f45"),
    "CANYON": dict(seabed="#8a5a3a", sand="#d9965b", grass="#c97a45", grass2="#a85a35",
                   rock="#8c4a2f", snow="#e8b88a", water="#3f9aa8", trunk="#6b4426",
                   leaf="#7a8a3a", leaf2="#5a6a2a", stone="#9a5a3a", cactus="#5a8a40"),
    "SNOW": dict(seabed="#5a6a78", sand="#c9d4dc", grass="#e6eef3", grass2="#cbd8e2",
                 rock="#6c7480", snow="#ffffff", water="#5b8fb0", trunk="#4a3524",
                 leaf="#2f5d4a", leaf2="#e8f0f4", stone="#7d8590", cactus="#4f7a5a"),
    "AUTUMN": dict(seabed="#7a6a4a", sand="#c9b07a", grass="#b5a642", grass2="#8a6a2a",
                   rock="#7a6a5a", snow="#f4f2ee", water="#3f86a0", trunk="#5a3a22",
                   leaf="#d9822b", leaf2="#b5452b", stone="#8a8070", cactus="#6a8a40"),
}
PALETTE_ITEMS = [(k, k.title(), "") for k in PALETTES]


def to_linear(c):
    return tuple(x / 12.92 if x <= 0.04045 else ((x + 0.055) / 1.055) ** 2.4 for x in c)


def color(palette, key):
    return to_linear(_hex(PALETTES[palette][key]))


def get_material():
    """One opaque material for terrain + every asset, driven by vertex colors."""
    mat = bpy.data.materials.get(MATERIAL_NAME)
    if mat:
        return mat
    mat = bpy.data.materials.new(MATERIAL_NAME)
    mat.use_nodes = True
    nt = mat.node_tree
    bsdf = nt.nodes.get("Principled BSDF")
    attr = nt.nodes.new("ShaderNodeVertexColor")
    attr.layer_name = COLOR_ATTR
    attr.location = (-300, 200)
    nt.links.new(attr.outputs["Color"], bsdf.inputs["Base Color"])
    bsdf.inputs["Roughness"].default_value = 0.9
    for name in ("Specular", "Specular IOR Level"):
        if name in bsdf.inputs:
            bsdf.inputs[name].default_value = 0.15
    return mat


def get_water_material(palette):
    mat = bpy.data.materials.get(WATER_MAT_NAME)
    if mat is None:
        mat = bpy.data.materials.new(WATER_MAT_NAME)
        mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    c = color(palette, "water")
    bsdf.inputs["Base Color"].default_value = (*c, 1.0)
    bsdf.inputs["Roughness"].default_value = 0.15
    mat.diffuse_color = (*c, 1.0)  # solid-mode color
    return mat


def set_face_colors(mesh, face_colors):
    """Write one RGB per polygon to the corner color attribute in one call."""
    attr = mesh.color_attributes.get(COLOR_ATTR)
    if attr is None:
        attr = mesh.color_attributes.new(COLOR_ATTR, "FLOAT_COLOR", "CORNER")
    n = len(mesh.polygons)
    totals = np.empty(n, dtype=np.int32)
    mesh.polygons.foreach_get("loop_total", totals)
    rgba = np.ones((n, 4), dtype=np.float32)
    rgba[:, :3] = np.asarray(face_colors, dtype=np.float32).reshape(n, 3)
    attr.data.foreach_set("color", np.repeat(rgba, totals, axis=0).ravel())
    mesh.color_attributes.active_color = attr
    try:
        mesh.color_attributes.render_color_index = mesh.color_attributes.active_color_index
    except AttributeError:
        pass


def vary(c, rng, amount):
    if amount <= 0:
        return c
    f = 1.0 + rng.uniform(-amount, amount)
    return tuple(min(1.0, max(0.0, x * f)) for x in c)


def paint_terrain(obj, s):
    """Color each face from its height band and slope."""
    mesh = obj.data
    n = len(mesh.polygons)
    if n == 0:
        return
    nv = len(mesh.vertices)
    co = np.empty(nv * 3, dtype=np.float32)
    mesh.vertices.foreach_get("co", co)
    co = co.reshape(nv, 3)
    tris = np.empty(n * 3, dtype=np.int32)
    mesh.polygons.foreach_get("vertices", tris)  # all faces are triangles
    tri = co[tris.reshape(n, 3)]
    cz = tri[:, :, 2].mean(axis=1) / max(s.height, 1e-6)
    nrm = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    nz = nrm[:, 2] / np.maximum(np.linalg.norm(nrm, axis=1), 1e-9)

    p = s.palette
    seabed, sand, grass, grass2, rock, snow = (
        np.array(color(p, k), dtype=np.float32)
        for k in ("seabed", "sand", "grass", "grass2", "rock", "snow"))

    water = s.water_level if s.use_water else -1.0
    out = np.empty((n, 3), dtype=np.float32)
    g_span = max(s.grass_level - s.sand_level, 1e-6)
    gt = np.clip((cz - s.sand_level) / g_span, 0, 1)[:, None]
    out[:] = grass * (1 - gt) + grass2 * gt
    out[cz < s.sand_level] = sand
    out[cz < water] = seabed
    out[cz >= s.grass_level] = rock
    out[cz >= s.snow_level] = snow
    steep = (nz < s.slope_rock) & (cz >= max(s.sand_level, water))
    out[steep] = rock

    if s.color_variation > 0:
        rng = np.random.default_rng(s.seed)
        out *= (1.0 + rng.uniform(-s.color_variation, s.color_variation, (n, 1))).astype(np.float32)
        np.clip(out, 0, 1, out=out)
    set_face_colors(mesh, out)
