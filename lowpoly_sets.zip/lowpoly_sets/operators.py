"""LPS_OT_* operators."""
import os
import random
import time

import bpy
from bpy_extras.io_utils import ExportHelper

from . import environment, presets, scatter, terrain, utils


def _finish(op, context, msg, t0):
    utils.update_stats(context.scene)
    utils.vertex_color_viewport(context)
    op.report({"INFO"}, f"{msg} ({(time.perf_counter() - t0) * 1000:.0f} ms)")


def _fast_eevee(context):
    s = context.scene.lps
    if s.use_fast_eevee and "fast_eevee_render" in context.preferences.addons:
        try:
            bpy.ops.fastr.apply_preset(preset="DRAFT")
        except (RuntimeError, AttributeError, TypeError):
            pass


class _Base:
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        utils.ensure_object_mode(context)
        t0 = time.perf_counter()
        msg = self.run(context)
        if msg is None:
            return {"CANCELLED"}
        _finish(self, context, msg, t0)
        return {"FINISHED"}


class LPS_OT_generate_scene(_Base, bpy.types.Operator):
    bl_idname = "lps.generate_scene"
    bl_label = "Generate Full Scene"
    bl_description = "Terrain, colors, scatter, water, sky, sun and camera in one go"

    def run(self, context):
        s = context.scene.lps
        if not s.preset_applied:
            presets.apply_preset(s, s.preset)
        terrain.build_terrain(context)
        n = scatter.scatter(context)
        environment.build_environment(context.scene)
        if context.scene.camera is None or context.scene.camera.name == utils.CAM_NAME:
            environment.build_camera(context.scene)
        _fast_eevee(context)
        return f"Scene built: {n} props"


class LPS_OT_randomize_seed(_Base, bpy.types.Operator):
    bl_idname = "lps.randomize_seed"
    bl_label = "Randomize"
    bl_description = "New random seed, then rebuild terrain and scatter"

    def run(self, context):
        s = context.scene.lps
        from . import props
        props.SUSPEND[0] = True
        s.seed = random.randint(0, 99999)
        props.SUSPEND[0] = False
        if not s.preset_applied:
            presets.apply_preset(s, s.preset)
        terrain.build_terrain(context)
        scatter.scatter(context)
        environment.build_water(context.scene)
        return f"Seed {s.seed}"


class LPS_OT_apply_preset(_Base, bpy.types.Operator):
    bl_idname = "lps.apply_preset"
    bl_label = "Load Preset Settings"
    bl_description = "Reset all settings to the chosen preset (does not build)"

    def run(self, context):
        s = context.scene.lps
        presets.apply_preset(s, s.preset)
        return "Preset loaded"


class LPS_OT_generate_terrain(_Base, bpy.types.Operator):
    bl_idname = "lps.generate_terrain"
    bl_label = "Generate Terrain"
    bl_description = "Rebuild the terrain mesh (reuses the same mesh data)"

    def run(self, context):
        obj = terrain.build_terrain(context)
        environment.build_water(context.scene)
        return f"Terrain: {len(obj.data.polygons)} tris"


class LPS_OT_repaint(_Base, bpy.types.Operator):
    bl_idname = "lps.repaint"
    bl_label = "Repaint"
    bl_description = "Recolor the terrain from the height bands"

    def run(self, context):
        obj = terrain.get_terrain()
        if obj is None:
            self.report({"WARNING"}, "Generate terrain first")
            return None
        terrain.palette.paint_terrain(obj, context.scene.lps)
        environment.build_water(context.scene)
        return "Repainted"


class LPS_OT_scatter(_Base, bpy.types.Operator):
    bl_idname = "lps.scatter"
    bl_label = "Scatter"
    bl_description = "Place props on the terrain"

    def run(self, context):
        if terrain.get_terrain() is None:
            self.report({"WARNING"}, "Generate terrain first")
            return None
        return f"Scattered {scatter.scatter(context)} props"


class LPS_OT_clear_scatter(_Base, bpy.types.Operator):
    bl_idname = "lps.clear_scatter"
    bl_label = "Clear"
    bl_description = "Remove all scattered props"

    def run(self, context):
        scatter.clear_scatter(context.scene)
        return "Scatter cleared"


class LPS_OT_add_environment(_Base, bpy.types.Operator):
    bl_idname = "lps.add_environment"
    bl_label = "Update Environment"
    bl_description = "Water, flat sky, sun and optional fog"

    def run(self, context):
        environment.build_environment(context.scene)
        return "Environment updated"


class LPS_OT_add_camera(_Base, bpy.types.Operator):
    bl_idname = "lps.add_camera"
    bl_label = "Add Camera"
    bl_description = "Hero shot or orbit camera, set as the scene camera"

    def run(self, context):
        environment.build_camera(context.scene)
        return "Camera set"


class LPS_OT_bake(_Base, bpy.types.Operator):
    bl_idname = "lps.bake"
    bl_label = "Merge Scatter"
    bl_description = "Join all scattered props into one mesh: lowest viewport lag"

    def run(self, context):
        n = scatter.bake_scatter(context)
        return f"Merged {n} objects" if n else "Nothing to merge"


class LPS_OT_export(bpy.types.Operator, ExportHelper):
    bl_idname = "lps.export"
    bl_label = "Export Set"
    bl_description = "Export terrain, water and props for a game engine"
    filename_ext = ".glb"

    fmt: bpy.props.EnumProperty(name="Format", items=[("GLB", "glTF (.glb)", ""),
                                                      ("FBX", "FBX (.fbx)", "")])
    filter_glob: bpy.props.StringProperty(default="*.glb;*.fbx", options={"HIDDEN"})

    def execute(self, context):
        utils.ensure_object_mode(context)
        root = bpy.data.collections.get(utils.ROOT_COLL)
        if root is None:
            self.report({"WARNING"}, "Nothing to export")
            return {"CANCELLED"}
        for o in context.view_layer.objects:
            o.select_set(False)
        for o in root.all_objects:
            if o.type == "MESH" and o.name in context.view_layer.objects:
                o.select_set(True)
        ext = ".glb" if self.fmt == "GLB" else ".fbx"
        path = os.path.splitext(self.filepath)[0] + ext
        if self.fmt == "GLB":
            bpy.ops.export_scene.gltf(filepath=path, export_format="GLB", use_selection=True)
        else:
            try:
                bpy.ops.export_scene.fbx(filepath=path, use_selection=True, colors_type="SRGB")
            except TypeError:
                bpy.ops.export_scene.fbx(filepath=path, use_selection=True)
        self.report({"INFO"}, f"Exported {path}")
        return {"FINISHED"}


classes = (LPS_OT_generate_scene, LPS_OT_randomize_seed, LPS_OT_apply_preset,
           LPS_OT_generate_terrain, LPS_OT_repaint, LPS_OT_scatter, LPS_OT_clear_scatter,
           LPS_OT_add_environment, LPS_OT_add_camera, LPS_OT_bake, LPS_OT_export)
