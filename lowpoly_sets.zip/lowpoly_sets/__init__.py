bl_info = {
    "name": "Low Poly Sets",
    "author": "Alexander Ernest",
    "version": (1, 0, 0),
    "blender": (3, 6, 0),
    "location": "3D View > Sidebar (N) > Low Poly",
    "description": "Low-poly terrain generator with props, water, sky and "
                   "one-click set-scene presets, built for low lag",
    "category": "Add Mesh",
}

if "bpy" in locals():
    import importlib
    for _m in (utils, palette, terrain, props_gen, scatter, environment, presets, props,
               operators, panels):
        importlib.reload(_m)
else:
    from . import (utils, palette, terrain, props_gen, scatter, environment, presets, props,
                   operators, panels)

import bpy


def register():
    props.register()
    for c in operators.classes + panels.classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(operators.classes + panels.classes):
        bpy.utils.unregister_class(c)
    props.unregister()
