"""Sidebar UI: 3D View > N > Low Poly. Draw code only reads stored values."""
import bpy

from . import props_gen, utils


class _Panel:
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Low Poly"


class LPS_PT_main(_Panel, bpy.types.Panel):
    bl_idname = "LPS_PT_main"
    bl_label = "Low Poly Sets"

    def draw(self, context):
        s = context.scene.lps
        col = self.layout.column(align=True)
        row = col.row(align=True)
        row.prop(s, "preset", text="")
        row.operator("lps.apply_preset", text="", icon="FILE_REFRESH")
        row = col.row(align=True)
        row.prop(s, "seed")
        row.operator("lps.randomize_seed", text="", icon="SHADERFX")
        col.separator()
        col.operator("lps.generate_scene", icon="WORLD", text="Generate Full Scene")

        box = self.layout.box()
        r = box.row()
        r.label(text=f"{s.stat_tris:,} tris · {s.stat_objects} objects")
        if s.stat_tris > utils.TRI_BUDGET or s.stat_objects > utils.OBJ_BUDGET:
            box.label(text="Over budget: lower counts or Merge Scatter", icon="ERROR")


class LPS_PT_terrain(_Panel, bpy.types.Panel):
    bl_label = "Terrain"
    bl_parent_id = "LPS_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        s = context.scene.lps
        col = self.layout.column(align=True)
        for p in ("falloff", "noise_type", "size", "subdivisions", "height", "noise_scale",
                  "octaves", "terrace_steps", "edge_drop", "jitter"):
            col.prop(s, p)
        col.separator()
        row = col.row(align=True)
        row.operator("lps.generate_terrain", icon="MESH_GRID")
        row.prop(s, "live_update", toggle=True, icon="TIME", text="")


class LPS_PT_colors(_Panel, bpy.types.Panel):
    bl_label = "Colors"
    bl_parent_id = "LPS_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        s = context.scene.lps
        col = self.layout.column(align=True)
        col.prop(s, "palette")
        col.prop(s, "use_water")
        sub = col.column(align=True)
        sub.active = s.use_water
        sub.prop(s, "water_level")
        for p in ("sand_level", "grass_level", "snow_level", "slope_rock", "color_variation"):
            col.prop(s, p)
        col.operator("lps.repaint", icon="BRUSH_DATA")


class LPS_PT_scatter(_Panel, bpy.types.Panel):
    bl_label = "Scatter"
    bl_parent_id = "LPS_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        s = context.scene.lps
        layout = self.layout
        layout.prop(s, "scatter_mode", expand=True)
        for kind, label, _d in props_gen.ASSET_TYPES:
            item = getattr(s, "sc_" + kind.lower())
            box = layout.box()
            row = box.row(align=True)
            row.prop(item, "show", text="", emboss=False,
                     icon="TRIA_DOWN" if item.show else "TRIA_RIGHT")
            row.prop(item, "enabled", text=label)
            sub = row.row()
            sub.active = item.enabled
            sub.prop(item, "count", text="")
            if item.show:
                c = box.column(align=True)
                c.active = item.enabled
                r = c.row(align=True)
                r.prop(item, "scale_min")
                r.prop(item, "scale_max")
                r = c.row(align=True)
                r.prop(item, "min_h")
                r.prop(item, "max_h")
                c.prop(item, "max_slope")
        if s.scatter_mode == "OBJECTS":
            row = layout.row(align=True)
            row.prop(s, "bounds_display")
            sub = row.row()
            sub.active = s.bounds_display
            sub.prop(s, "bounds_threshold", text="")
        row = layout.row(align=True)
        row.operator("lps.scatter", icon="PARTICLES")
        row.operator("lps.clear_scatter", icon="TRASH")


class LPS_PT_environment(_Panel, bpy.types.Panel):
    bl_label = "Environment"
    bl_parent_id = "LPS_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        s = context.scene.lps
        col = self.layout.column(align=True)
        col.prop(s, "time_of_day")
        col.prop(s, "sky_color")
        col.prop(s, "sun_color")
        col.prop(s, "sun_elevation")
        col.prop(s, "sun_azimuth")
        col.prop(s, "sun_strength")
        row = col.row(align=True)
        row.prop(s, "use_fog")
        sub = row.row()
        sub.active = s.use_fog
        sub.prop(s, "fog_density")
        col.operator("lps.add_environment", icon="LIGHT_SUN")
        col.separator()
        row = col.row(align=True)
        row.prop(s, "camera_mode", text="")
        row.operator("lps.add_camera", icon="CAMERA_DATA")


class LPS_PT_finish(_Panel, bpy.types.Panel):
    bl_label = "Finish"
    bl_parent_id = "LPS_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        s = context.scene.lps
        col = self.layout.column(align=True)
        col.operator("lps.bake", icon="AUTOMERGE_ON")
        col.operator("lps.export", icon="EXPORT")
        col.prop(s, "use_fast_eevee")


classes = (LPS_PT_main, LPS_PT_terrain, LPS_PT_colors, LPS_PT_scatter,
           LPS_PT_environment, LPS_PT_finish)
