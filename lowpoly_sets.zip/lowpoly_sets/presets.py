"""Set-scene presets: one dict per scene type."""
from . import environment, props_gen

PRESETS = {
    "ISLAND": dict(
        label="Island", size=24, height=4, noise_type="PERLIN", noise_scale=1.0, octaves=4,
        falloff="ISLAND", terrace_steps=0, edge_drop=0.0, jitter=0.35, palette="TROPICAL",
        use_water=True, water_level=0.18, sand_level=0.26, grass_level=0.92, snow_level=1.1,
        slope_rock=0.72, time_of_day="NOON",
        scatter=dict(PALM=40, TREE=20, BUSH=30, ROCK=25, GRASS=60)),
    "DESERT": dict(
        label="Desert", size=28, height=2.5, noise_type="BLENDER", noise_scale=1.2, octaves=3,
        falloff="NONE", terrace_steps=0, edge_drop=0.15, jitter=0.4, palette="DESERT",
        use_water=False, water_level=0.0, sand_level=0.7, grass_level=0.9, snow_level=1.1,
        slope_rock=0.8, time_of_day="SUNSET",
        scatter=dict(CACTUS=40, ROCK=40, BUSH=15)),
    "VALLEY": dict(
        label="Mountain Valley", size=30, height=8, noise_type="RIDGED", noise_scale=1.0,
        octaves=5, falloff="VALLEY", terrace_steps=0, edge_drop=0.0, jitter=0.3,
        palette="FOREST", use_water=True, water_level=0.06, sand_level=0.09,
        grass_level=0.55, snow_level=0.8, slope_rock=0.75, time_of_day="MORNING",
        scatter=dict(PINE=120, TREE=40, ROCK=40, GRASS=80)),
    "FOREST": dict(
        label="Forest", size=24, height=3, noise_type="PERLIN", noise_scale=1.4, octaves=4,
        falloff="NONE", terrace_steps=0, edge_drop=0.1, jitter=0.35, palette="FOREST",
        use_water=False, water_level=0.0, sand_level=0.0, grass_level=0.85, snow_level=1.1,
        slope_rock=0.7, time_of_day="MORNING",
        scatter=dict(PINE=150, TREE=110, BUSH=60, ROCK=30, GRASS=100)),
    "SNOW": dict(
        label="Snow Peak", size=26, height=7, noise_type="RIDGED", noise_scale=1.2, octaves=5,
        falloff="RADIAL", terrace_steps=0, edge_drop=0.0, jitter=0.3, palette="SNOW",
        use_water=False, water_level=0.0, sand_level=0.0, grass_level=0.6, snow_level=0.55,
        slope_rock=0.7, time_of_day="NOON",
        scatter=dict(PINE=120, ROCK=40)),
    "CANYON": dict(
        label="Canyon", size=28, height=6, noise_type="PERLIN", noise_scale=0.9, octaves=4,
        falloff="CANYON", terrace_steps=6, edge_drop=0.0, jitter=0.2, palette="CANYON",
        use_water=True, water_level=0.08, sand_level=0.14, grass_level=0.5, snow_level=1.1,
        slope_rock=0.85, time_of_day="MORNING",
        scatter=dict(CACTUS=25, ROCK=60, BUSH=20)),
    "AUTUMN": dict(
        label="Autumn Hills", size=24, height=3.5, noise_type="PERLIN", noise_scale=1.1,
        octaves=4, falloff="NONE", terrace_steps=0, edge_drop=0.1, jitter=0.35,
        palette="AUTUMN", use_water=True, water_level=0.12, sand_level=0.16,
        grass_level=0.85, snow_level=1.1, slope_rock=0.7, time_of_day="SUNSET",
        scatter=dict(TREE=120, PINE=30, BUSH=40, ROCK=25, GRASS=60)),
}
PRESET_ITEMS = [(k, v["label"], "") for k, v in PRESETS.items()]


def apply_preset(s, key):
    from . import props
    p = PRESETS[key]
    props.SUSPEND[0] = True
    try:
        for k, v in p.items():
            if k not in ("label", "scatter"):
                setattr(s, k, v)
        for k, v in environment.TIME_PRESETS[p["time_of_day"]].items():
            setattr(s, k, v)
        for kind in props_gen.ASSET_KEYS:
            item = getattr(s, "sc_" + kind.lower())
            for k, v in props_gen.ASSET_DEFAULTS[kind].items():
                setattr(item, k, v)
            item.count = p["scatter"].get(kind, 0)
            item.enabled = kind in p["scatter"]
        s.preset_applied = True
    finally:
        props.SUSPEND[0] = False
