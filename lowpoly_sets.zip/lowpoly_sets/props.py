"""Scene settings. Changes do nothing until you press a button, unless Live Update is on."""
import bpy
from bpy.props import (BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty,
                       IntProperty, PointerProperty)

from . import environment, palette, presets, props_gen, terrain

SUSPEND = [False]
_pending = set()
DEBOUNCE = 0.3


def _live_tick():
    ctx = bpy.context
    scene = ctx.scene
    jobs = set(_pending)
    _pending.clear()
    if not scene or not scene.lps.live_update:
        return None
    from . import scatter, utils
    if "terrain" in jobs:
        terrain.build_terrain(ctx)
        environment.build_water(scene)
        coll = bpy.data.collections.get(utils.SCATTER_COLL)
        if coll and coll.objects:
            scatter.scatter(ctx)
    elif "paint" in jobs:
        obj = terrain.get_terrain()
        if obj:
            terrain.palette.paint_terrain(obj, scene.lps)
            environment.build_water(scene)
    utils.update_stats(scene)
    return None


def _schedule(job):
    def update(self, context):
        if SUSPEND[0] or not self.live_update or terrain.get_terrain() is None:
            return
        _pending.add(job)
        if bpy.app.timers.is_registered(_live_tick):
            bpy.app.timers.unregister(_live_tick)
        bpy.app.timers.register(_live_tick, first_interval=DEBOUNCE)
    return update


_terrain_up = _schedule("terrain")
_paint_up = _schedule("paint")


def _preset_up(self, context):
    if not SUSPEND[0]:
        presets.apply_preset(self, self.preset)


def _time_up(self, context):
    if SUSPEND[0]:
        return
    SUSPEND[0] = True
    try:
        for k, v in environment.TIME_PRESETS[self.time_of_day].items():
            setattr(self, k, v)
    finally:
        SUSPEND[0] = False
    if bpy.data.objects.get("LPS_Sun"):
        environment.build_world(context.scene)
        environment.build_sun(context.scene)


class LPS_ScatterItem(bpy.types.PropertyGroup):
    enabled: BoolProperty(name="Enabled", default=False)
    show: BoolProperty(name="Show Options", default=False)
    count: IntProperty(name="Count", default=30, min=0, max=2000, soft_max=400)
    scale_min: FloatProperty(name="Min Scale", default=0.8, min=0.05, max=10)
    scale_max: FloatProperty(name="Max Scale", default=1.2, min=0.05, max=10)
    min_h: FloatProperty(name="Min Height", default=0.0, min=0, max=1.5, subtype="FACTOR",
                         description="Lowest placement, as a fraction of terrain height")
    max_h: FloatProperty(name="Max Height", default=1.0, min=0, max=1.5, subtype="FACTOR")
    max_slope: FloatProperty(name="Max Slope", default=35, min=0, max=90,
                             description="Steepest ground allowed, in degrees")


class LPS_Settings(bpy.types.PropertyGroup):
    preset: EnumProperty(name="Preset", items=presets.PRESET_ITEMS, update=_preset_up)
    preset_applied: BoolProperty(default=False)
    seed: IntProperty(name="Seed", default=1, min=0, update=_terrain_up)
    live_update: BoolProperty(name="Live Update", default=False,
                              description="Rebuild terrain 0.3 s after you stop dragging a "
                                          "slider (off = fastest)")

    # Terrain
    size: FloatProperty(name="Size", default=24, min=2, max=500, unit="LENGTH",
                        update=_terrain_up)
    subdivisions: IntProperty(name="Resolution", default=48, min=4, max=128,
                              description="Grid cuts per side. 48 ≈ 4.6k tris, 128 ≈ 33k",
                              update=_terrain_up)
    height: FloatProperty(name="Height", default=4, min=0, max=200, update=_terrain_up)
    noise_type: EnumProperty(name="Noise", items=terrain.NOISE_ITEMS, update=_terrain_up)
    noise_scale: FloatProperty(name="Noise Scale", default=1.0, min=0.05, max=20,
                               update=_terrain_up)
    octaves: IntProperty(name="Detail", default=4, min=1, max=8, update=_terrain_up)
    falloff: EnumProperty(name="Shape", items=terrain.FALLOFF_ITEMS, default="ISLAND",
                          update=_terrain_up)
    terrace_steps: IntProperty(name="Terraces", default=0, min=0, max=30,
                               update=_terrain_up)
    edge_drop: FloatProperty(name="Edge Drop", default=0, min=0, max=1, subtype="FACTOR",
                             update=_terrain_up)
    jitter: FloatProperty(name="Facet Jitter", default=0.35, min=0, max=1, subtype="FACTOR",
                          update=_terrain_up)

    # Colors
    palette: EnumProperty(name="Palette", items=palette.PALETTE_ITEMS, update=_paint_up)
    use_water: BoolProperty(name="Water", default=True, update=_paint_up)
    water_level: FloatProperty(name="Water", default=0.18, min=0, max=1, subtype="FACTOR",
                               update=_paint_up)
    sand_level: FloatProperty(name="Sand", default=0.26, min=0, max=1.5, subtype="FACTOR",
                              update=_paint_up)
    grass_level: FloatProperty(name="Grass → Rock", default=0.75, min=0, max=1.5,
                               subtype="FACTOR", update=_paint_up)
    snow_level: FloatProperty(name="Snow", default=1.1, min=0, max=1.5, subtype="FACTOR",
                              update=_paint_up)
    slope_rock: FloatProperty(name="Cliff Steepness", default=0.72, min=0, max=1,
                              subtype="FACTOR",
                              description="Faces steeper than this turn to rock "
                                          "(1 = flat, 0 = vertical)", update=_paint_up)
    color_variation: FloatProperty(name="Color Variation", default=0.06, min=0, max=0.5,
                                   update=_paint_up)

    # Scatter
    scatter_mode: EnumProperty(name="Mode", items=[
        ("OBJECTS", "Objects", "Linked duplicates you can move one by one"),
        ("MERGED", "Merged", "One mesh for everything (lowest lag)")])
    bounds_display: BoolProperty(name="Boxes When Heavy", default=False,
                                 description="Show scatter as boxes in the viewport above "
                                             "the threshold (renders normally)")
    bounds_threshold: IntProperty(name="Threshold", default=500, min=0)

    # Environment
    time_of_day: EnumProperty(name="Time", items=environment.TIME_ITEMS, default="NOON",
                              update=_time_up)
    sky_color: FloatVectorProperty(name="Sky", subtype="COLOR", size=3, min=0, max=1,
                                   default=(0.35, 0.63, 1.0))
    sun_color: FloatVectorProperty(name="Sun Color", subtype="COLOR", size=3, min=0, max=1,
                                   default=(1.0, 0.97, 0.92))
    sun_elevation: FloatProperty(name="Sun Height", default=60, min=-10, max=90)
    sun_azimuth: FloatProperty(name="Sun Direction", default=140, min=0, max=360)
    sun_strength: FloatProperty(name="Sun Strength", default=4, min=0, max=50)
    use_fog: BoolProperty(name="Fog", default=False,
                          description="Volumetric fog (costs render time)")
    fog_density: FloatProperty(name="Density", default=0.008, min=0, max=0.2, precision=4)
    camera_mode: EnumProperty(name="Camera", items=[
        ("HERO", "Hero Shot", "Fixed 3/4 view"),
        ("ORBIT", "Orbit", "Turntable over the frame range")])
    use_fast_eevee: BoolProperty(name="Use Fast EEVEE Draft", default=True,
                                 description="If the Fast EEVEE Render add-on is enabled, "
                                             "apply its Draft preset after generating")

    # Stats (written by operators so the panel never has to count)
    stat_tris: IntProperty()
    stat_objects: IntProperty()


def _make_scatter_annotations():
    for kind in props_gen.ASSET_KEYS:
        LPS_Settings.__annotations__["sc_" + kind.lower()] = PointerProperty(type=LPS_ScatterItem)


_make_scatter_annotations()

classes = (LPS_ScatterItem, LPS_Settings)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.lps = PointerProperty(type=LPS_Settings)


def unregister():
    if bpy.app.timers.is_registered(_live_tick):
        bpy.app.timers.unregister(_live_tick)
    del bpy.types.Scene.lps
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
