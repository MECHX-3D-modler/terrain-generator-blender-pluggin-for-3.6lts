"""Procedural low-poly assets. Every mesh is triangles only and < 100 tris."""
import math
import random

import bmesh
from mathutils import Matrix

from . import palette, utils

ASSET_TYPES = [
    ("PINE", "Pine", "Stacked-cone conifer"),
    ("TREE", "Round Tree", "Trunk with a faceted crown"),
    ("PALM", "Palm", "Curved trunk with leaf fan"),
    ("BUSH", "Bush", "Squashed low-poly blob"),
    ("ROCK", "Rock", "Jagged boulder"),
    ("CACTUS", "Cactus", "Column cactus with arms"),
    ("GRASS", "Grass", "Small tuft of blades"),
]
ASSET_KEYS = [a[0] for a in ASSET_TYPES]
VARIANTS = {"ROCK": 3}
DEFAULT_VARIANTS = 2

# scale range, height band (fraction of terrain height), max slope (deg)
ASSET_DEFAULTS = {
    "PINE":   dict(scale_min=0.8, scale_max=1.4, min_h=0.08, max_h=0.85, max_slope=35),
    "TREE":   dict(scale_min=0.8, scale_max=1.3, min_h=0.08, max_h=0.60, max_slope=30),
    "PALM":   dict(scale_min=0.9, scale_max=1.3, min_h=0.00, max_h=0.65, max_slope=25),
    "BUSH":   dict(scale_min=0.6, scale_max=1.1, min_h=0.00, max_h=0.70, max_slope=35),
    "ROCK":   dict(scale_min=0.4, scale_max=1.3, min_h=0.00, max_h=1.00, max_slope=60),
    "CACTUS": dict(scale_min=0.7, scale_max=1.2, min_h=0.00, max_h=0.80, max_slope=30),
    "GRASS":  dict(scale_min=0.6, scale_max=1.0, min_h=0.00, max_h=0.60, max_slope=30),
}
SPACING = {"PINE": 0.7, "TREE": 0.9, "PALM": 0.9, "CACTUS": 0.6}


class _Builder:
    def __init__(self):
        self.bm = bmesh.new()
        self.part = self.bm.faces.layers.int.new("part")
        self.colors = []

    def _tag(self, ret, key):
        if key not in self.colors:
            self.colors.append(key)
        idx = self.colors.index(key)
        faces = {f for v in ret["verts"] for f in v.link_faces}
        for f in faces:
            f[self.part] = idx
        return ret["verts"]

    def cone(self, key, r1, r2, depth, segs, mat):
        ret = bmesh.ops.create_cone(self.bm, cap_ends=True, cap_tris=True, segments=segs,
                                    radius1=r1, radius2=r2, depth=depth,
                                    matrix=mat @ Matrix.Translation((0, 0, depth / 2)))
        return self._tag(ret, key)

    def ico(self, key, radius, mat):
        ret = bmesh.ops.create_icosphere(self.bm, subdivisions=1, radius=radius, matrix=mat)
        return self._tag(ret, key)

    def finish(self, name, pal, rng):
        bmesh.ops.triangulate(self.bm, faces=self.bm.faces[:])
        base = {k: palette.color(pal, k) for k in self.colors}
        face_cols = [palette.vary(base[self.colors[f[self.part]]], rng, 0.06)
                     for f in self.bm.faces]
        mesh = utils.get_mesh(name)
        self.bm.to_mesh(mesh)
        self.bm.free()
        palette.set_face_colors(mesh, face_cols)
        mesh.materials.clear()
        mesh.materials.append(palette.get_material())
        return mesh


T = Matrix.Translation
S = Matrix.Diagonal


def _pine(b, rng):
    b.cone("trunk", 0.07, 0.05, 0.4, 5, Matrix())
    z, r = 0.3, 0.55
    for i in range(3):
        b.cone("leaf2" if i % 2 else "leaf", r, 0.0, 0.6, 6,
               T((0, 0, z)) @ Matrix.Rotation(rng.uniform(0, 1), 4, "Z"))
        z += 0.35
        r *= 0.72


def _tree(b, rng):
    b.cone("trunk", 0.08, 0.06, 0.7, 5, Matrix())
    v = b.ico("leaf", 0.45, T((0, 0, 0.95)) @ S((1.0, 1.0, 0.85, 1.0)))
    for vert in v:
        vert.co.x *= rng.uniform(0.88, 1.12)
        vert.co.y *= rng.uniform(0.88, 1.12)


def _palm(b, rng):
    x, z = 0.0, 0.0
    bend = rng.uniform(0.06, 0.12)
    for i in range(4):
        b.cone("trunk", 0.07 - i * 0.01, 0.06 - i * 0.01, 0.45, 5, T((x, 0, z)))
        x += bend
        z += 0.43
    b.cone("leaf", 0.85, 0.0, 0.22, 6, T((x, 0, z - 0.12)))
    b.cone("leaf2", 0.55, 0.0, 0.2, 5, T((x, 0, z - 0.02)) @ Matrix.Rotation(0.5, 4, "Z"))


def _bush(b, rng):
    v = b.ico("leaf2", 0.3, T((0, 0, 0.15)) @ S((1.2, 1.0, 0.75, 1.0)))
    for vert in v:
        vert.co.x *= rng.uniform(0.9, 1.1)
        vert.co.y *= rng.uniform(0.9, 1.1)


def _rock(b, rng):
    v = b.ico("stone", 0.32, T((0, 0, 0.08)) @ S((1.0, rng.uniform(0.7, 1.0), 0.6, 1.0)))
    for vert in v:
        vert.co.x += rng.uniform(-0.06, 0.06)
        vert.co.y += rng.uniform(-0.06, 0.06)
        vert.co.z += rng.uniform(-0.04, 0.05)


def _cactus(b, rng):
    b.cone("cactus", 0.09, 0.08, 1.0, 6, Matrix())
    for side in (-1, 1):
        if rng.random() < 0.8:
            h = rng.uniform(0.3, 0.55)
            b.cone("cactus", 0.05, 0.05, 0.18, 5,
                   T((0, 0, h)) @ Matrix.Rotation(side * math.pi / 2, 4, "Y"))
            b.cone("cactus", 0.05, 0.045, 0.3, 5, T((side * 0.17, 0, h - 0.02)))


def _grass(b, rng):
    for i in range(3):
        a = i * 2.1 + rng.uniform(0, 0.5)
        b.cone("grass", 0.04, 0.0, rng.uniform(0.18, 0.3), 3,
               T((math.cos(a) * 0.05, math.sin(a) * 0.05, 0))
               @ Matrix.Rotation(rng.uniform(-0.3, 0.3), 4, "X"))


BUILDERS = {"PINE": _pine, "TREE": _tree, "PALM": _palm, "BUSH": _bush,
            "ROCK": _rock, "CACTUS": _cactus, "GRASS": _grass}


def build_asset_meshes(kind, pal, seed):
    """Build (or refresh in place) the variant meshes for one asset type."""
    meshes = []
    for i in range(VARIANTS.get(kind, DEFAULT_VARIANTS)):
        rng = random.Random(seed * 1009 + ASSET_KEYS.index(kind) * 31 + i)
        b = _Builder()
        BUILDERS[kind](b, rng)
        meshes.append(b.finish(f"LPS_Asset_{kind}_{i}", pal, rng))
    return meshes
