"""Place assets on the terrain. Linked duplicates (shared mesh) or one merged mesh."""
import math
import random

import bpy
import numpy as np
from mathutils import Euler, Matrix, Vector
from mathutils.bvhtree import BVHTree

from . import palette, props_gen, utils

MAX_INSTANCES = 2000


def clear_scatter(scene):
    coll = bpy.data.collections.get(utils.SCATTER_COLL)
    if coll and coll.objects:
        bpy.data.batch_remove(list(coll.objects))
    utils.purge_own_orphans()


def _placements(scene, terrain):
    s = scene.lps
    mesh = terrain.data
    mw = terrain.matrix_world
    verts = [mw @ v.co for v in mesh.vertices]
    bvh = BVHTree.FromPolygons(verts, [p.vertices[:] for p in mesh.polygons])
    rng = random.Random(s.seed + 7)
    half = s.size * 0.5 * 0.97
    top = s.height * 2 + 10
    water = s.water_level + 0.01 if s.use_water else -1.0
    taken = set()
    out = []
    budget = MAX_INSTANCES
    for kind in props_gen.ASSET_KEYS:
        item = getattr(s, "sc_" + kind.lower())
        if not item.enabled or item.count <= 0:
            continue
        want = min(item.count, budget)
        cos_max = math.cos(math.radians(item.max_slope))
        spacing = props_gen.SPACING.get(kind)
        placed = 0
        tries = 0
        while placed < want and tries < want * 8:
            tries += 1
            x, y = rng.uniform(-half, half), rng.uniform(-half, half)
            loc, nrm, _i, _d = bvh.ray_cast(Vector((x, y, top)), Vector((0, 0, -1)))
            if loc is None:
                continue
            t = loc.z / max(s.height, 1e-6)
            if t < water or t < item.min_h or t > item.max_h or nrm.z < cos_max:
                continue
            if spacing:
                cell = (int(x // spacing), int(y // spacing))
                if cell in taken:
                    continue
                taken.add(cell)
            sc = rng.uniform(item.scale_min, max(item.scale_min, item.scale_max))
            tilt = 0.25 if kind in ("ROCK", "GRASS", "BUSH") else 0.06
            rot = Euler((rng.uniform(-tilt, tilt), rng.uniform(-tilt, tilt),
                         rng.uniform(0, math.tau)))
            mat = Matrix.Translation(loc - Vector((0, 0, 0.04 * sc))) @ rot.to_matrix().to_4x4() \
                @ Matrix.Scale(sc, 4)
            out.append((kind, rng.randrange(1 << 16), mat))
            placed += 1
        budget -= placed
        if budget <= 0:
            break
    return out


def merge_meshes(pairs, name):
    """Join (mesh, matrix) pairs into one triangle mesh with numpy (no bpy.ops)."""
    cos, tris, cols = [], [], []
    offset = 0
    cache = {}
    for mesh, mat in pairs:
        if mesh.name not in cache:
            nv, nf = len(mesh.vertices), len(mesh.polygons)
            co = np.empty(nv * 3, np.float32)
            mesh.vertices.foreach_get("co", co)
            fv = np.empty(nf * 3, np.int32)
            mesh.polygons.foreach_get("vertices", fv)
            attr = mesh.color_attributes.get(palette.COLOR_ATTR)
            c = np.empty(nf * 3 * 4, np.float32)
            attr.data.foreach_get("color", c)
            cache[mesh.name] = (co.reshape(nv, 3), fv.reshape(nf, 3), c.reshape(nf, 3 * 4))
        co, fv, c = cache[mesh.name]
        m = np.array(mat, dtype=np.float32)
        cos.append(co @ m[:3, :3].T + m[:3, 3])
        tris.append(fv + offset)
        cols.append(c)
        offset += len(co)
    merged = utils.get_mesh(name)
    if not pairs:
        return merged
    v = np.concatenate(cos)
    f = np.concatenate(tris)
    merged.vertices.add(len(v))
    merged.vertices.foreach_set("co", v.ravel())
    merged.loops.add(len(f) * 3)
    merged.loops.foreach_set("vertex_index", f.ravel())
    merged.polygons.add(len(f))
    merged.polygons.foreach_set("loop_start", np.arange(0, len(f) * 3, 3, dtype=np.int32))
    try:
        merged.polygons.foreach_set("loop_total", np.full(len(f), 3, np.int32))
    except (AttributeError, TypeError, RuntimeError):
        pass  # Blender 4.x derives loop_total from loop_start
    merged.update(calc_edges=True)
    attr = merged.color_attributes.new(palette.COLOR_ATTR, "FLOAT_COLOR", "CORNER")
    attr.data.foreach_set("color", np.concatenate(cols).ravel())
    merged.color_attributes.active_color = attr
    merged.materials.clear()
    merged.materials.append(palette.get_material())
    return merged


def scatter(context):
    scene = context.scene
    s = scene.lps
    terrain = bpy.data.objects.get(utils.TERRAIN_NAME)
    if terrain is None:
        return 0
    clear_scatter(scene)
    merged_obj = bpy.data.objects.get(utils.MERGED_NAME)
    if merged_obj:
        bpy.data.objects.remove(merged_obj)
    places = _placements(scene, terrain)
    meshes = {k: props_gen.build_asset_meshes(k, s.palette, s.seed)
              for k in {p[0] for p in places}}
    coll = utils.scatter_collection(scene)

    if s.scatter_mode == "MERGED":
        pairs = [(meshes[k][r % len(meshes[k])], m) for k, r, m in places]
        mesh = merge_meshes(pairs, utils.MERGED_NAME)
        utils.get_object(utils.MERGED_NAME, mesh, coll)
    else:
        bounds = s.bounds_display and len(places) > s.bounds_threshold
        for i, (kind, r, mat) in enumerate(places):
            # Unique names up front: Blender's name-collision search is slow
            obj = bpy.data.objects.new(f"LPS_{kind}_{i:04d}", meshes[kind][r % len(meshes[kind])])
            obj.matrix_world = mat
            if bounds:
                obj.display_type = "BOUNDS"
            coll.objects.link(obj)
    utils.purge_own_orphans()
    return len(places)


def bake_scatter(context):
    """Merge every scatter object into one mesh object (fastest viewport)."""
    scene = context.scene
    coll = bpy.data.collections.get(utils.SCATTER_COLL)
    if not coll:
        return 0
    objs = [o for o in coll.objects if o.type == "MESH" and o.name != utils.MERGED_NAME]
    if not objs:
        return 0
    pairs = [(o.data, o.matrix_world.copy()) for o in objs]
    old = bpy.data.objects.get(utils.MERGED_NAME)
    if old:
        pairs.append((old.data.copy(), old.matrix_world.copy()))
        bpy.data.objects.remove(old)
    mesh = merge_meshes(pairs, utils.MERGED_NAME + "_tmp")
    bpy.data.batch_remove(objs)
    stale = bpy.data.meshes.get(utils.MERGED_NAME)
    if stale and stale.users == 0:
        bpy.data.meshes.remove(stale)
    mesh.name = utils.MERGED_NAME
    utils.get_object(utils.MERGED_NAME, mesh, coll)
    utils.purge_own_orphans()
    return len(objs)
